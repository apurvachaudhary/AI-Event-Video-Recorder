import cv2, time
from video_buffer import VideoBuffer
from event_detector import MockEventDetector
from gps_simulator import get_gps
from metadata_manager import save_metadata
from config import *

def main():
    cap = cv2.VideoCapture(VIDEO_SOURCE)
    buffer = VideoBuffer()
    detector = MockEventDetector()

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        buffer.add_frame(frame)

        event = detector.detect_event(frame)
        if event:
            gps = get_gps()
            post_frames = []
            start = time.time()
            while time.time() - start < POST_EVENT_DURATION:
                ret, f = cap.read()
                if not ret:
                    break
                post_frames.append(f)
            filename, timestamp = buffer.save_clip(post_frames, event, gps)
            save_metadata(event, timestamp, filename, gps)

        cv2.imshow("Event Recorder", frame)
        if cv2.waitKey(1) == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
