# 🎥 AI Event-Based Video Recorder

This project demonstrates **event-based video recording** using a mock AI event detector.
When an event (e.g., overspeed, lane departure, sudden brake) is detected, the system saves a **30-second video clip** (15s before + 15s after) along with simulated GPS metadata.

## 🚀 Features
- Continuous **video buffering** using OpenCV
- **Mock AI event detection** (replaceable with YOLO)
- **Event-based video saving**
- **Metadata logging** in JSON
- Optional **Flask API** to view/download events

## ⚙️ Run Instructions
```bash
pip install -r requirements.txt
python main.py
```
Press **q** to quit webcam stream.

To view saved events via API:
```bash
python app.py
```
Then open: http://127.0.0.1:5000/events
