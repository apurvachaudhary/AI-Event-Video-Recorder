import random

class MockEventDetector:
    def __init__(self, event_types=["overspeed", "lane_departure", "sudden_brake"]):
        self.event_types = event_types

    def detect_event(self, frame):
        if random.random() < 0.005:
            event = random.choice(self.event_types)
            print(f"[EVENT DETECTED] {event}")
            return event
        return None
