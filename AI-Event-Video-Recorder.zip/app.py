from flask import Flask, jsonify, send_file
import json
from config import *

app = Flask(__name__)

@app.route("/events")
def list_events():
    with open(METADATA_FILE, 'r') as f:
        data = json.load(f)
    return jsonify(data)

@app.route("/download/<filename>")
def download_clip(filename):
    return send_file(f"{SAVE_DIR}{filename}", as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)
