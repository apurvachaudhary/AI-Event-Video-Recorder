import cv2, collections, os
from datetime import datetime
from config import *

class VideoBuffer:
    def __init__(self):
        self.buffer = collections.deque(maxlen=BUFFER_DURATION * FRAME_RATE)
        os.makedirs(SAVE_DIR, exist_ok=True)

    def add_frame(self, frame):
        self.buffer.append(frame)

    def save_clip(self, post_frames, event_type, gps_data):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{SAVE_DIR}{event_type}_{timestamp}.mp4"
        h, w, _ = self.buffer[0].shape
        out = cv2.VideoWriter(filename, cv2.VideoWriter_fourcc(*'mp4v'), FRAME_RATE, (w, h))
        for f in list(self.buffer) + post_frames:
            out.write(f)
        out.release()
        print(f"[INFO] Saved clip: {filename}")
        return filename, timestamp
