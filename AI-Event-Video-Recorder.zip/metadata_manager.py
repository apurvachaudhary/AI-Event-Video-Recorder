import json, os
from config import METADATA_FILE

def save_metadata(event_type, timestamp, filename, gps):
    entry = {
        "event_type": event_type,
        "timestamp": timestamp,
        "file": filename,
        "gps": gps
    }
    if not os.path.exists(METADATA_FILE):
        data = []
    else:
        with open(METADATA_FILE, 'r') as f:
            data = json.load(f)
    data.append(entry)
    with open(METADATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)
