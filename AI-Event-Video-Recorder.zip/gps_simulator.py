import random

def get_gps():
    lat = round(random.uniform(28.6, 28.7), 6)
    lon = round(random.uniform(77.1, 77.3), 6)
    return {"latitude": lat, "longitude": lon}
